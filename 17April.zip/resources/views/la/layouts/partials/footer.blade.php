@if(!isset($no_padding))
<footer class="main-footer">
    <div class="pull-right hidden-xs">
        Developed by <a href="https://www.pksol.com/">PKSOL</a>
    </div>
    <strong>Copyright &copy; 2019
</footer>
@endif