Dear User,<br><br>

{{-- You have been registered on {{ url('/') }}.<br><br> --}}

Your login credentials for the same are as below:<br><br>

Username: Nehal<br>
password: password <br><br>
12
{{-- You can login on <a href="{{ url('/login') }}">{{ str_replace("http://", "", url('/login')) }}</a>.<br><br> --}}

Best Regards,